Viafont Font

The Viafont font is a geometric, sans-serif font that resembles the Viacom logo. I designed this font in FontLab Studio. It includes alphanumeric characters, punctuation and international characters. Like all other fonts that I made, this font has a Euro sign and is Public Domain. Please read the terms of use at http://jlhfonts.blogspot.com/.